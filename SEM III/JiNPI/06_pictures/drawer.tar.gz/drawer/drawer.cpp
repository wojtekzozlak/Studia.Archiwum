#include <SDL.h>
#include <stdio.h>

#include "images.hh"

void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel); 

int main() { 
    SDL_Surface *screen; 
    int quit = 0; 
    SDL_Event event; 
    coord_t i, j;
    image_t f;
    point_t p;

    p = point_t(0, 0);
    f = rings(p, 20);

    // Initialize Video
    if (SDL_Init(SDL_INIT_VIDEO) == -1) { 
        fprintf(stderr, "Could not initialize SDL: %s.\n", SDL_GetError()); 
        return -1; 
    } 
    screen = SDL_SetVideoMode(800, 600, 24, SDL_HWPALETTE);
    if (screen == NULL) { 
        fprintf(stderr, "Couldn't set video mode: %s\n", SDL_GetError()); 
        return -2; 
    } 

    while (!quit) { 
        // Poll for events 
        while (SDL_PollEvent(&event)) { 
            switch (event.type) { 
                case SDL_KEYUP: 
                    if (event.key.keysym.sym == SDLK_ESCAPE) quit = 1; 
                    break; 
                case SDL_QUIT: 
                    quit = 1;
                    break; 
                default:
                    break;
            }
        }

        // Lock the screen for direct access to the pixels 
        if (SDL_MUSTLOCK(screen)) { 
            if (SDL_LockSurface(screen) < 0) { 
                fprintf(stderr, "Can't lock screen: %s\n", SDL_GetError()); 
                return -3; 
            } 
        } 

        // Plot the function
        for (i = 0; i < screen->w; i++) {
            for (j = 0; j < screen->h; j++) {
                p = point_t(i - 400, j - 300);
                putpixel(screen, i, j, f(p));
            }
        }

        // Unlock Surface if necessary 
        if (SDL_MUSTLOCK(screen)) { 
            SDL_UnlockSurface(screen); 
        } 

        // Update screen
        SDL_UpdateRect(screen, 0, 0, 0, 0); 
    } 

    SDL_Quit(); 
  
    return 0; 
} 

void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel) { 
    int bpp = surface->format->BytesPerPixel; 
    // Here p is the address to the pixel we want to set 
    Uint8 *p = (Uint8*) surface->pixels + y * surface->pitch + x * bpp; 

    switch(bpp) { 
        case 1: 
            *p = pixel; 
            break; 
        case 2: 
            *(Uint16 *)p = pixel; 
            break; 
        case 3: 
            if (SDL_BYTEORDER == SDL_BIG_ENDIAN) {
                p[0] = (pixel >> 16) & 0xff; 
                p[1] = (pixel >> 8) & 0xff; 
                p[2] = pixel & 0xff; 
            } else { 
                p[0] = pixel & 0xff; 
                p[1] = (pixel >> 8) & 0xff; 
                p[2] = (pixel >> 16) & 0xff; 
            } 
            break; 
        case 4: 
            *(Uint32 *)p = pixel; 
            break;
        default:
            break;
    } 
}

